from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import os, subprocess

DEFAULT_ARGS = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5)
}

def run_consumer(**context):
    # In production this would use KubernetesPodOperator or DockerOperator.
    cmd = "python /workspace/consumer_etl.py --topic events"
    print("Running:", cmd)
    subprocess.run(cmd, shell=True, check=True)

with DAG(
    dag_id="etl_with_quality_checks",
    default_args=DEFAULT_ARGS,
    schedule_interval="@hourly",
    start_date=datetime(2025, 1, 1),
    catchup=False
) as dag:

    start = BashOperator(task_id="start", bash_command="echo 'Starting ETL run'")

    run_etl = PythonOperator(task_id="run_etl", python_callable=run_consumer)

    validate = BashOperator(task_id="run_great_expectations", bash_command="great_expectations checkpoint run basic_validation || true")

    start >> run_etl >> validate
