# Realtime Data Quality Pipeline

**Purpose:** A reference data engineering repository demonstrating a production-ready **realtime ingestion + ETL + data quality** workflow.  
Designed to impress other data engineers: includes Kafka-based ingestion, a Python consumer ETL writing to Postgres, Great Expectations checks, and an Airflow DAG for orchestration and monitoring.

This repository focuses on an _ongoing problem_ for data engineers: **maintaining data quality and observability in streaming pipelines** while enabling reliable downstream consumption.

---

## Architecture (local/dev)
- **Producer**: `producer.py` — simulates event streams into Kafka topics.
- **Kafka** + **Zookeeper** — message bus (docker-compose services).
- **Consumer ETL**: `consumer_etl.py` — reads events, enriches/validates, writes to Postgres.
- **Postgres** — serves as the data warehouse for processed events.
- **Great Expectations** — validates data post-load and emits validation results.
- **Airflow** (optional) — DAG `dags/etl_dag.py` shows orchestration: backfills, run validations, alerting hooks.
- **CI** — basic lint/test workflow in `.github/workflows/ci.yml`.

This repo is meant as a template you can drop into a real environment, adapt connectors, and extend with metrics/monitoring (Prometheus/Grafana), schema registry, or a real data catalog.

---

## Quick start (dev)
Requirements: Docker & Docker Compose, Python 3.9+

1. Download and unzip the repo, then from the repo root run:
   ```bash
   docker-compose up -d
   ```
   This starts Kafka, Zookeeper and Postgres.

2. Install Python dependencies (recommended in virtualenv):
   ```bash
   pip install -r requirements.txt
   ```

3. Start a producer to generate events:
   ```bash
   python producer.py --topic events --rate 5
   ```

4. Run the consumer ETL locally (or use the provided Airflow DAG):
   ```bash
   python consumer_etl.py --topic events
   ```

5. Run data quality checks:
   ```bash
   great_expectations checkpoint run basic_validation
   ```
   (There is a minimal Great Expectations config in `great_expectations/`.)

---

## What makes this impressive
- Focus on **data quality** in a streaming context (Great Expectations + validation reporting).
- Clear separation of concerns: producer, transformer, storage, validation, orchestration.
- Reproducible local stack using Docker Compose.
- Extensible: swap Postgres for Snowflake/BigQuery, swap Kafka for Kinesis, add schema registry and CI gating.

---

## Files of interest
- `producer.py` — event generator
- `consumer_etl.py` — transformation + write logic
- `docker-compose.yml` — local infra
- `dags/etl_dag.py` — orchestration example for Airflow
- `great_expectations/` — expectations + sample data docs skeleton

---
Feel free to adapt/extend. If you want, I can also produce Kubernetes manifests, Terraform infra, or integrate a metrics pipeline (Prometheus + Grafana) next.
