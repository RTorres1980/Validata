#!/usr/bin/env python3
"""producer.py
Simple Kafka event producer that simulates user events for a streaming pipeline.
Usage: python producer.py --topic events --rate 5
"""
import argparse, json, time, random
from datetime import datetime
from kafka import KafkaProducer

def random_event():
    user_id = random.randint(1, 200)
    return {
        "event_id": f"evt-{int(time.time()*1000)}-{random.randint(0,999)}",
        "user_id": user_id,
        "user_tenure_days": random.randint(0, 2000),
        "action": random.choice(["click", "view", "purchase", "submit", "error"]),
        "amount": round(random.random()*100, 2),
        "metadata": {"source": random.choice(["web","mobile","api"])},
        "ts": datetime.utcnow().isoformat() + "Z"
    }

def main(topic='events', rate=1, bootstrap='localhost:9092'):
    producer = KafkaProducer(bootstrap_servers=bootstrap,
                             value_serializer=lambda v: json.dumps(v).encode('utf-8'))
    print(f"Producing to topic={topic} rate={rate}/s")
    try:
        while True:
            ev = random_event()
            producer.send(topic, ev)
            print(f"-> {ev['event_id']} {ev['action']} user:{ev['user_id']}")
            time.sleep(1.0/float(rate))
    except KeyboardInterrupt:
        print('Stopping producer')
    finally:
        producer.flush()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--topic', default='events')
    parser.add_argument('--rate', type=float, default=1.0, help='events per second')
    args = parser.parse_args()
    main(args.topic, args.rate)
