#!/usr/bin/env python3
"""consumer_etl.py
Consumes from Kafka, performs lightweight transformations and validation, writes to Postgres.
Usage: python consumer_etl.py --topic events
"""
import argparse, json, time, os, sys
from kafka import KafkaConsumer
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
from datetime import datetime

POSTGRES_CONN = {
    "host": os.getenv("POSTGRES_HOST","localhost"),
    "port": int(os.getenv("POSTGRES_PORT",5432)),
    "dbname": os.getenv("POSTGRES_DB","events_db"),
    "user": os.getenv("POSTGRES_USER","airflow"),
    "password": os.getenv("POSTGRES_PASSWORD","airflow")
}

TABLE_SCHEMA = """CREATE TABLE IF NOT EXISTS public.events_processed (
    event_id TEXT PRIMARY KEY,
    user_id INT,
    user_tenure_days INT,
    action TEXT,
    amount NUMERIC,
    source TEXT,
    ts TIMESTAMP
);"""

def validate_event(rec):
    # lightweight validation rules
    if not rec.get('event_id') or not rec.get('user_id'):
        return False, 'missing_ids'
    if rec.get('amount',0) < 0:
        return False, 'negative_amount'
    if rec.get('action') not in ['click','view','purchase','submit','error']:
        return False, 'unknown_action'
    return True, None

def to_row(rec):
    return (
        rec['event_id'],
        int(rec['user_id']),
        int(rec.get('user_tenure_days') or 0),
        rec.get('action'),
        float(rec.get('amount') or 0),
        rec.get('metadata',{}).get('source'),
        datetime.fromisoformat(rec['ts'].replace('Z',''))
    )

def ensure_table(conn):
    with conn.cursor() as cur:
        cur.execute(TABLE_SCHEMA)
        conn.commit()

def write_batch(conn, rows):
    with conn.cursor() as cur:
        sql = "INSERT INTO public.events_processed (event_id,user_id,user_tenure_days,action,amount,source,ts) VALUES %s ON CONFLICT (event_id) DO NOTHING"
        execute_values(cur, sql, rows)
        conn.commit()

def main(topic='events', bootstrap='localhost:9092', group='etl-group'):
    consumer = KafkaConsumer(topic, bootstrap_servers=bootstrap,
                             value_deserializer=lambda m: json.loads(m.decode('utf-8')),
                             group_id=group,
                             auto_offset_reset='earliest',
                             enable_auto_commit=False)
    # Postgres conn
    conn = psycopg2.connect(**POSTGRES_CONN)
    ensure_table(conn)
    batch = []
    BATCH_SIZE = 100
    print(f"Consuming topic={topic}")
    try:
        for msg in consumer:
            rec = msg.value
            valid, reason = validate_event(rec)
            if not valid:
                print(f"[SKIP] {rec.get('event_id')} reason={reason}")
                # TODO: route to dead-letter topic or store for inspection
                continue
            batch.append(to_row(rec))
            if len(batch) >= BATCH_SIZE:
                write_batch(conn, batch)
                print(f"WROTE BATCH {len(batch)} to Postgres")
                batch = []
                consumer.commit()
    except KeyboardInterrupt:
        print('Stopping consumer')
    finally:
        if batch:
            write_batch(conn, batch)
            print(f"WROTE FINAL BATCH {len(batch)} to Postgres")
        conn.close()
